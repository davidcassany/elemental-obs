/*
Copyright © 2022 - 2026 SUSE LLC

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package tpm_test

import (
	"testing"

	"github.com/google/go-attestation/attest"
	gotpm "github.com/rancher-sandbox/go-tpm"
)

// TestTPMChallengeRoundTrip exercises the full TPM challenge-response flow
// using an emulated TPM with a fixed seed, similar to what elemental-register
// and elemental-operator do during machine registration.
func TestTPMChallengeRoundTrip(t *testing.T) {
	const seed = int64(127)

	// Step 1: Client generates auth token (creates AK, returns token + AK bytes).
	token, akBytes, err := gotpm.GetAuthToken(gotpm.Emulated, gotpm.WithSeed(seed))
	if err != nil {
		t.Fatalf("GetAuthToken failed: %v", err)
	}
	if len(akBytes) == 0 {
		t.Fatal("GetAuthToken returned empty AK bytes")
	}
	t.Logf("Token length: %d, AK bytes length: %d", len(token), len(akBytes))

	// Step 2: Server parses the auth token to get EK and attestation data.
	ek, attestationData, err := gotpm.GetAttestationData(token)
	if err != nil {
		t.Fatalf("GetAttestationData failed: %v", err)
	}
	if ek == nil || ek.Public == nil {
		t.Fatal("GetAttestationData returned nil EK or EK.Public")
	}
	if attestationData == nil || attestationData.AK == nil {
		t.Fatal("GetAttestationData returned nil attestation data or AK")
	}
	t.Logf("EK public key type: %T", ek.Public)
	t.Logf("AK Public bytes: %d, CreateData: %d, CreateAttestation: %d, CreateSignature: %d",
		len(attestationData.AK.Public),
		len(attestationData.AK.CreateData),
		len(attestationData.AK.CreateAttestation),
		len(attestationData.AK.CreateSignature))

	// Step 3: Validate AK parameters directly (CheckAKParameters is the first thing
	// GenerateChallenge calls internally via ap.Generate()).
	ap := attest.ActivationParameters{
		EK: ek.Public,
		AK: *attestationData.AK,
	}
	if err := ap.CheckAKParameters(); err != nil {
		t.Fatalf("CheckAKParameters failed: %v", err)
	}
	t.Log("CheckAKParameters passed")

	// Step 4: Server generates challenge.
	secret, challengeBytes, err := gotpm.GenerateChallenge(ek, attestationData)
	if err != nil {
		t.Fatalf("GenerateChallenge failed: %v", err)
	}
	t.Logf("Challenge bytes length: %d, secret length: %d", len(challengeBytes), len(secret))

	// Step 5: Client activates credential using a fake channel that serves the
	// challenge bytes and captures the response.
	ch := newFakeChannel(challengeBytes)
	if err := gotpm.Authenticate(akBytes, ch, gotpm.Emulated, gotpm.WithSeed(seed)); err != nil {
		t.Fatalf("Client Authenticate failed: %v", err)
	}
	t.Logf("Client response bytes length: %d", len(ch.response))

	// Step 6: Server validates challenge response.
	if err := gotpm.ValidateChallenge(secret, ch.response); err != nil {
		t.Fatalf("ValidateChallenge failed: %v", err)
	}
	t.Log("Full TPM challenge-response round trip succeeded")
}

// fakeChannel implements io.ReadWriter to simulate the WebSocket channel
// between client and server. It serves challenge bytes on Read and captures
// the response on Write.
type fakeChannel struct {
	challenge []byte
	pos       int
	response  []byte
}

func newFakeChannel(challenge []byte) *fakeChannel {
	return &fakeChannel{challenge: challenge}
}

func (c *fakeChannel) Read(p []byte) (int, error) {
	if c.pos >= len(c.challenge) {
		return 0, nil
	}
	n := copy(p, c.challenge[c.pos:])
	c.pos += n
	return n, nil
}

func (c *fakeChannel) Write(p []byte) (int, error) {
	c.response = append(c.response, p...)
	return len(p), nil
}
